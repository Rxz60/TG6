import { ENV } from "./env";

type SignOptions = { signal?: AbortSignal; timeoutMs?: number };

export async function getSignedObjectUrl(
  operation: "put" | "get",
  path: string,
  options: SignOptions = {}
): Promise<string> {
  if (!/^[A-Za-z0-9/_-]{1,160}$/.test(path) || path.includes("..")) {
    throw new Error("Invalid storage path");
  }
  const baseUrl = ENV.forgeApiUrl.trim();
  const apiKey = ENV.forgeApiKey;
  if (!baseUrl || !apiKey) throw new Error("Storage service is not configured");

  const base = `${baseUrl.replace(/\/+$/, "")}/`;
  const endpoint = new URL(`v1/storage/presign/${operation}`, base);
  endpoint.searchParams.set("path", path);
  const timeoutSignal = AbortSignal.timeout(options.timeoutMs ?? 8_000);
  const signal = options.signal
    ? AbortSignal.any([options.signal, timeoutSignal])
    : timeoutSignal;
  const response = await fetch(endpoint, {
    headers: { Authorization: `Bearer ${apiKey}` },
    signal,
  });
  if (!response.ok) {
    throw new Error(`Storage signing failed with status ${response.status}`);
  }
  const result = (await response.json()) as { url?: unknown };
  if (typeof result.url !== "string") {
    throw new Error("Storage service did not return a URL");
  }
  const signedUrl = new URL(result.url);
  if (signedUrl.protocol !== "https:") {
    throw new Error("Storage service returned a non-HTTPS URL");
  }
  return signedUrl.toString();
}
