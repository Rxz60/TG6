import type { Express, NextFunction, Request, Response } from "express";
import express from "express";
import * as db from "../db";
import { getSignedObjectUrl } from "./objectStorage";
import { sdk } from "./sdk";

type IncomingMessage = {
  role: "user" | "assistant";
  content: string;
  attachmentIds: string[];
};

type ModelPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string; detail: "auto" } }
  | {
      type: "file_url";
      file_url: {
        url: string;
        mime_type:
          | "audio/mpeg"
          | "audio/wav"
          | "audio/mp4"
          | "video/mp4"
          | "application/pdf";
      };
    };

function startChatDeadline(req: Request, res: Response, next: NextFunction) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 50_000);
  res.locals.tg6Controller = controller;
  res.once("finish", () => clearTimeout(timeout));
  res.once("close", () => {
    clearTimeout(timeout);
    if (!res.writableEnded) controller.abort();
  });
  req.once("aborted", () => controller.abort());
  next();
}

function parseChatBody(
  req: Request,
  res: Response,
  next: (error?: unknown) => void
) {
  express.json({ limit: "128kb" })(req, res, error => {
    if (!error) {
      next();
      return;
    }
    if (req.aborted || res.destroyed) return;
    const status = (error as { status?: number }).status;
    res.status(status === 413 ? 413 : 400).json({
      error:
        status === 413
          ? "حجم طلب المحادثة كبير جدًا. أرسلها على أجزاء أصغر."
          : "تعذّر قراءة الرسالة. تحقق من محتواها وحاول مجددًا.",
    });
  });
}

function parseMessages(value: unknown): IncomingMessage[] | null {
  if (!Array.isArray(value) || value.length === 0 || value.length > 24) {
    return null;
  }
  const parsed: IncomingMessage[] = [];
  let totalLength = 0;
  let totalAttachments = 0;
  for (const item of value) {
    if (
      !item ||
      (item.role !== "user" && item.role !== "assistant") ||
      typeof item.content !== "string" ||
      item.content.length > 12_000
    ) {
      return null;
    }
    const attachmentIds = item.attachmentIds ?? [];
    if (
      !Array.isArray(attachmentIds) ||
      attachmentIds.length > 4 ||
      attachmentIds.some(
        (id: unknown) =>
          typeof id !== "string" || id.length < 8 || id.length > 64
      ) ||
      (item.role !== "user" && attachmentIds.length > 0) ||
      (!item.content.trim() && attachmentIds.length === 0)
    ) {
      return null;
    }
    totalLength += item.content.length;
    totalAttachments += attachmentIds.length;
    parsed.push({ role: item.role, content: item.content, attachmentIds });
  }
  if (
    parsed.at(-1)?.role !== "user" ||
    totalLength > 30_000 ||
    totalAttachments > 8
  ) {
    return null;
  }
  return parsed;
}

async function makeModelMessages(
  userId: number,
  messages: IncomingMessage[],
  signal: AbortSignal
): Promise<
  Array<{ role: "user" | "assistant"; content: string | ModelPart[] }>
> {
  const ids = Array.from(
    new Set(messages.flatMap(message => message.attachmentIds))
  );
  const records = await db.getTg6AttachmentsByIds(userId, ids);
  if (records.length !== ids.length) {
    throw new Error(
      "One or more attachments are not available to this account"
    );
  }
  const byId = new Map(records.map(record => [record.id, record]));
  const urls = new Map<string, string>();
  await Promise.all(
    records.map(async record => {
      urls.set(
        record.id,
        await getSignedObjectUrl("get", record.storagePath, {
          signal,
          timeoutMs: 7_500,
        })
      );
    })
  );

  return Promise.all(
    messages.map(async message => {
      if (message.attachmentIds.length === 0) {
        return { role: message.role, content: message.content };
      }
      const parts: ModelPart[] = [];
      if (message.content.trim())
        parts.push({ type: "text", text: message.content });
      else
        parts.push({
          type: "text",
          text: "حلّل المرفق أو المرفقات التالية وأجب عنها.",
        });

      for (const id of message.attachmentIds) {
        const record = byId.get(id);
        const url = urls.get(id);
        if (!record || !url) continue;
        if (record.contentType.startsWith("image/")) {
          parts.push({
            type: "image_url",
            image_url: { url, detail: "auto" },
          });
        } else if (
          [
            "audio/mpeg",
            "audio/wav",
            "audio/mp4",
            "video/mp4",
            "application/pdf",
          ].includes(record.contentType)
        ) {
          parts.push({
            type: "file_url",
            file_url: {
              url,
              mime_type: record.contentType as Extract<
                ModelPart,
                { type: "file_url" }
              >["file_url"]["mime_type"],
            },
          });
        } else {
          parts.push({
            type: "text",
            text: `المرفق «${record.name}» (${record.contentType}) محفوظ في المحادثة، لكن هذا النوع غير مدعوم للتحليل المباشر حاليًا.`,
          });
        }
      }
      return { role: message.role, content: parts };
    })
  );
}

function awaitWithAbort<T>(
  promise: Promise<T>,
  signal: AbortSignal
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const onAbort = () => {
      signal.removeEventListener("abort", onAbort);
      reject(new Error("TG6 request deadline exceeded"));
    };
    if (signal.aborted) {
      onAbort();
      return;
    }
    signal.addEventListener("abort", onAbort, { once: true });
    promise.then(
      value => {
        signal.removeEventListener("abort", onAbort);
        resolve(value);
      },
      error => {
        signal.removeEventListener("abort", onAbort);
        reject(error);
      }
    );
  });
}

async function streamChat(req: Request, res: Response) {
  const controller = res.locals.tg6Controller as AbortController;
  if (res.destroyed) return;
  const messages = parseMessages(req.body?.messages);
  if (!messages) {
    res.status(400).json({ error: "تعذّر التحقق من الرسائل أو المرفقات." });
    return;
  }

  let userId: number;
  try {
    const user = await awaitWithAbort(
      sdk.authenticateRequest(req),
      controller.signal
    );
    if (user.id < 1) throw new Error("A signed-in account is required");
    userId = user.id;
  } catch {
    if (res.destroyed) return;
    if (controller.signal.aborted) {
      res.status(504).json({ error: "استغرق إعداد الرد وقتًا طويلًا." });
      return;
    }
    res.status(401).json({ error: "سجّل الدخول لحساب Manus قبل استخدام TG6." });
    return;
  }

  const apiUrl = process.env.MANUS_API_URL?.trim().replace(/\/$/, "");
  const apiKey = process.env.MANUS_API_KEY;
  if (!apiUrl || !apiKey) {
    res.status(503).json({ error: "خدمة TG6 غير مهيأة حاليًا." });
    return;
  }

  try {
    const modelMessages = await awaitWithAbort(
      makeModelMessages(userId, messages, controller.signal),
      controller.signal
    );
    if (controller.signal.aborted || res.destroyed) return;
    const upstream = await fetch(`${apiUrl}/v1/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        Accept: "text/event-stream",
      },
      body: JSON.stringify({
        stream: true,
        max_tokens: 2048,
        messages: [
          {
            role: "system",
            content:
              "أنت TG6، مساعد ذكاء اصطناعي مفيد وواضح. أجب بلغة المستخدم، والعربية هي لغتك الافتراضية. كن ودودًا ودقيقًا وعمليًا. نظّم الرد بعناوين أو نقاط عند الحاجة، ولا تدّعِ تنفيذ إجراءات أو امتلاك إمكانات لم تُنفذ فعليًا. يمكن للمستخدم إرفاق صور وPDF وصيغ صوت/فيديو مدعومة؛ الملفات الأخرى قد تُحفظ دون تحليل. طلبات إنشاء المواقع أو بوتات Discord/Telegram لا تعني أن النشر الخارجي متاح تلقائيًا؛ وضّح بصدق ما هو موصول فعليًا ولا تقل إنك نشرت رابطًا قبل اكتمال ذلك.",
          },
          ...modelMessages,
        ],
      }),
      signal: controller.signal,
    });

    if (!upstream.ok || !upstream.body) {
      console.error("[TG6 LLM] Upstream returned status", upstream.status);
      if (!res.headersSent) {
        res.status(502).json({
          error: "واجه TG6 صعوبة في إنشاء الرد الآن. حاول مرة أخرى بعد قليل.",
        });
      }
      return;
    }

    res.status(200).set({
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    });
    res.flushHeaders();

    const reader = upstream.body.getReader();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (!res.write(Buffer.from(value))) {
          await new Promise<void>(resolve => {
            const finish = () => {
              res.off("drain", finish);
              res.off("close", finish);
              resolve();
            };
            res.once("drain", finish);
            res.once("close", finish);
          });
        }
        if (controller.signal.aborted || res.destroyed) break;
      }
    } finally {
      reader.releaseLock();
    }
    if (!res.destroyed && !res.writableEnded) res.end();
  } catch (error) {
    if (controller.signal.aborted && !res.writableEnded && !res.destroyed) {
      if (res.headersSent) {
        res.write(
          `data: ${JSON.stringify({ error: { message: "انتهت مهلة إنشاء الرد. حاول مرة أخرى." } })}\n\n`
        );
        res.end();
      } else {
        res.status(504).json({ error: "استغرق إعداد الرد وقتًا طويلًا." });
      }
    } else if (!res.destroyed && !res.writableEnded) {
      const safeMessage =
        error instanceof Error ? error.message : "unknown error";
      console.error("[TG6 Chat] Request failed:", safeMessage);
      if (res.headersSent) {
        res.write(
          `data: ${JSON.stringify({ error: { message: "تعذّر تحميل مرفق أو الاتصال بالمساعد." } })}\n\n`
        );
        res.end();
      } else {
        res.status(502).json({
          error: "تعذّر الاتصال بالمساعد الآن. حاول مرة أخرى بعد قليل.",
        });
      }
    }
  }
}

export function registerTg6ChatRoutes(app: Express) {
  app.post("/api/ai/chat", startChatDeadline, parseChatBody, (req, res) => {
    void streamChat(req, res);
  });

  app.get("/api/tg6/files/:id", async (req, res) => {
    let user: Awaited<ReturnType<typeof sdk.authenticateRequest>>;
    try {
      user = await sdk.authenticateRequest(req);
    } catch {
      res.status(401).send("Authentication required");
      return;
    }
    if (user.id < 1) {
      res.status(401).send("Authentication required");
      return;
    }
    try {
      const record = await db.getTg6Attachment(user.id, req.params.id);
      if (!record) {
        res.status(404).send("File not found");
        return;
      }
      const url = await getSignedObjectUrl("get", record.storagePath);
      res
        .set({
          "Cache-Control": "private, no-store",
          "Referrer-Policy": "no-referrer",
        })
        .redirect(302, url);
    } catch {
      res.status(503).send("File service unavailable");
    }
  });
}
