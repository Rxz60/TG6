import { and, desc, eq, inArray, isNotNull, isNull, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  Tg6Attachment,
  Tg6Conversation,
  tg6Attachments,
  tg6Conversations,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export type Tg6FileRef = {
  id: string;
  name: string;
  contentType: string;
  size: number;
};

export type Tg6Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
  attachments?: Tg6FileRef[];
};

export type Tg6ConversationData = {
  id: string;
  title: string;
  revision?: number;
  updatedAt: number;
  messages: Tg6Message[];
};

// Lazily create the Drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0)
      updateSet.lastSignedIn = new Date();

    await db
      .insert(users)
      .values(values)
      .onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

function decodeMessages(value: string): Tg6Message[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? (parsed as Tg6Message[]) : [];
  } catch {
    return [];
  }
}

function toConversation(row: Tg6Conversation): Tg6ConversationData {
  return {
    id: row.id,
    title: row.title,
    revision: row.revision,
    updatedAt: row.updatedAt.getTime(),
    messages: decodeMessages(row.messagesJson),
  };
}

export async function listTg6Conversations(
  userId: number
): Promise<{ conversations: Tg6ConversationData[]; deletedIds: string[] }> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select()
    .from(tg6Conversations)
    .where(eq(tg6Conversations.userId, userId))
    .orderBy(desc(tg6Conversations.updatedAt));
  return {
    conversations: rows.filter(row => !row.deletedAt).map(toConversation),
    deletedIds: rows.filter(row => row.deletedAt).map(row => row.id),
  };
}

export async function saveTg6Conversation(
  userId: number,
  conversation: Tg6ConversationData
): Promise<Tg6ConversationData> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const [existing] = await db
    .select()
    .from(tg6Conversations)
    .where(
      and(
        eq(tg6Conversations.userId, userId),
        eq(tg6Conversations.id, conversation.id)
      )
    )
    .limit(1);
  if (existing?.deletedAt) {
    throw new Error("Conversation has been deleted");
  }

  const updatedAt = new Date(conversation.updatedAt);
  const values = {
    title: conversation.title,
    messagesJson: JSON.stringify(conversation.messages),
    updatedAt,
  };
  if (existing) {
    const expectedRevision = conversation.revision ?? 0;
    if (existing.revision !== expectedRevision) return toConversation(existing);

    await db
      .update(tg6Conversations)
      .set({ ...values, revision: expectedRevision + 1 })
      .where(
        and(
          eq(tg6Conversations.userId, userId),
          eq(tg6Conversations.id, conversation.id),
          eq(tg6Conversations.revision, expectedRevision),
          isNull(tg6Conversations.deletedAt)
        )
      );
  } else {
    try {
      await db.insert(tg6Conversations).values({
        id: conversation.id,
        userId,
        ...values,
        revision: 1,
      });
    } catch (error) {
      const dbError = error as { code?: unknown; errno?: unknown } | null;
      const duplicate =
        dbError?.code === "ER_DUP_ENTRY" || dbError?.errno === 1062;
      if (!duplicate) throw error;

      const [sameOwner] = await db
        .select()
        .from(tg6Conversations)
        .where(
          and(
            eq(tg6Conversations.userId, userId),
            eq(tg6Conversations.id, conversation.id)
          )
        )
        .limit(1);
      if (!sameOwner) {
        throw new Error("Conversation ID is already owned by another account");
      }
      if (sameOwner.deletedAt) {
        throw new Error("Conversation has been deleted");
      }
      return toConversation(sameOwner);
    }
  }

  const [saved] = await db
    .select()
    .from(tg6Conversations)
    .where(
      and(
        eq(tg6Conversations.userId, userId),
        eq(tg6Conversations.id, conversation.id)
      )
    )
    .limit(1);
  if (!saved || saved.deletedAt)
    throw new Error("Failed to save TG6 conversation");
  return toConversation(saved);
}

export async function deleteTg6Conversation(userId: number, id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db
    .update(tg6Conversations)
    .set({
      title: "محادثة محذوفة",
      messagesJson: "[]",
      updatedAt: now,
      deletedAt: now,
      revision: sql`${tg6Conversations.revision} + 1`,
    })
    .where(
      and(
        eq(tg6Conversations.userId, userId),
        eq(tg6Conversations.id, id),
        isNull(tg6Conversations.deletedAt)
      )
    );
}

export async function createTg6Attachment(input: {
  id: string;
  userId: number;
  storagePath: string;
  name: string;
  contentType: string;
  size: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(tg6Attachments).values(input);
}

export async function completeTg6Attachment(userId: number, id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .update(tg6Attachments)
    .set({ uploadedAt: new Date() })
    .where(
      and(
        eq(tg6Attachments.userId, userId),
        eq(tg6Attachments.id, id),
        isNull(tg6Attachments.uploadedAt)
      )
    );
  return getTg6Attachment(userId, id);
}

export async function getTg6Attachment(
  userId: number,
  id: string
): Promise<Tg6Attachment | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const [row] = await db
    .select()
    .from(tg6Attachments)
    .where(
      and(
        eq(tg6Attachments.userId, userId),
        eq(tg6Attachments.id, id),
        isNotNull(tg6Attachments.uploadedAt)
      )
    )
    .limit(1);
  return row;
}

export async function getTg6AttachmentsByIds(
  userId: number,
  ids: string[]
): Promise<Tg6Attachment[]> {
  if (ids.length === 0) return [];
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db
    .select()
    .from(tg6Attachments)
    .where(
      and(
        eq(tg6Attachments.userId, userId),
        inArray(tg6Attachments.id, ids),
        isNotNull(tg6Attachments.uploadedAt)
      )
    );
}

export async function deletePendingTg6Attachment(userId: number, id: string) {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(tg6Attachments)
    .where(
      and(
        eq(tg6Attachments.userId, userId),
        eq(tg6Attachments.id, id),
        isNull(tg6Attachments.uploadedAt)
      )
    );
}
