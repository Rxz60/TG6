import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import * as db from "./db";
import { getSignedObjectUrl } from "./_core/objectStorage";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const fileRefSchema = z.object({
  id: z.string().min(8).max(64),
  name: z.string().min(1).max(255),
  contentType: z.string().min(1).max(128),
  size: z
    .number()
    .int()
    .min(0)
    .max(50 * 1024 * 1024),
});

const chatMessageSchema = z.object({
  id: z.string().min(8).max(64),
  role: z.enum(["user", "assistant"]),
  content: z.string().max(40_000),
  createdAt: z.number().int().nonnegative(),
  attachments: z.array(fileRefSchema).max(4).optional(),
});

const conversationSchema = z.object({
  id: z.string().min(8).max(64),
  title: z.string().min(1).max(255),
  revision: z.number().int().nonnegative().optional(),
  updatedAt: z.number().int().positive(),
  messages: z.array(chatMessageSchema).max(300),
});

const uploadsRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(255),
        contentType: z.string().max(128).optional(),
        size: z
          .number()
          .int()
          .positive()
          .max(50 * 1024 * 1024),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.id < 1) {
        throw new TRPCError({ code: "FORBIDDEN", message: "غير مسموح" });
      }
      const name = input.name
        .replace(/[\u0000-\u001f\u007f/\\]/g, " ")
        .trim()
        .slice(0, 255);
      const contentType = (input.contentType || "application/octet-stream")
        .trim()
        .slice(0, 128);
      if (!name) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "اسم الملف غير صالح.",
        });
      }

      const id = nanoid(24);
      const storagePath = `tg6/${ctx.user.id}/${nanoid(32)}`;
      await db.createTg6Attachment({
        id,
        userId: ctx.user.id,
        storagePath,
        name,
        contentType,
        size: input.size,
      });
      try {
        const uploadUrl = await getSignedObjectUrl("put", storagePath);
        return { id, name, contentType, size: input.size, uploadUrl };
      } catch (error) {
        await db.deletePendingTg6Attachment(ctx.user.id, id);
        console.error(
          "[TG6 Storage] Upload URL could not be created:",
          error instanceof Error ? error.message : "unknown error"
        );
        throw new TRPCError({
          code: "SERVICE_UNAVAILABLE",
          message: "تعذّر تهيئة الرفع الآن. حاول مرة أخرى.",
        });
      }
    }),
  complete: protectedProcedure
    .input(z.object({ id: z.string().min(8).max(64) }))
    .mutation(async ({ ctx, input }) => {
      const pending = await db.getTg6Attachment(ctx.user.id, input.id);
      if (pending) {
        return {
          id: pending.id,
          name: pending.name,
          contentType: pending.contentType,
          size: pending.size,
          downloadUrl: `/api/tg6/files/${encodeURIComponent(pending.id)}`,
        };
      }

      const dbConnection = await db.getDb();
      if (!dbConnection) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      }
      const { tg6Attachments } = await import("../drizzle/schema");
      const { and, eq, isNull } = await import("drizzle-orm");
      const [record] = await dbConnection
        .select()
        .from(tg6Attachments)
        .where(
          and(
            eq(tg6Attachments.userId, ctx.user.id),
            eq(tg6Attachments.id, input.id),
            isNull(tg6Attachments.uploadedAt)
          )
        )
        .limit(1);
      if (!record) {
        throw new TRPCError({ code: "NOT_FOUND", message: "الملف غير موجود." });
      }

      let uploaded = false;
      try {
        const signedGet = await getSignedObjectUrl("get", record.storagePath);
        const response = await fetch(signedGet, {
          headers: { Range: "bytes=0-0" },
          signal: AbortSignal.timeout(10_000),
        });
        const contentRange = response.headers.get("content-range");
        const rangeTotal = contentRange?.match(/\/(\d+)$/)?.[1];
        const contentLength = response.headers.get("content-length");
        const actualSize = Number(rangeTotal ?? contentLength);
        uploaded =
          response.ok &&
          Number.isSafeInteger(actualSize) &&
          actualSize === record.size &&
          actualSize <= 50 * 1024 * 1024;
        await response.body?.cancel();
      } catch {
        uploaded = false;
      }
      if (!uploaded) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "لم يكتمل رفع الملف. أعد المحاولة.",
        });
      }

      const completed = await db.completeTg6Attachment(ctx.user.id, input.id);
      if (!completed) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      }
      return {
        id: completed.id,
        name: completed.name,
        contentType: completed.contentType,
        size: completed.size,
        downloadUrl: `/api/tg6/files/${encodeURIComponent(completed.id)}`,
      };
    }),
  cancel: protectedProcedure
    .input(z.object({ id: z.string().min(8).max(64) }))
    .mutation(async ({ ctx, input }) => {
      await db.deletePendingTg6Attachment(ctx.user.id, input.id);
      return { success: true } as const;
    }),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  chat: router({
    list: protectedProcedure
      .input(z.object({ cacheScope: z.string().min(1).max(128) }))
      .query(({ ctx }) => db.listTg6Conversations(ctx.user.id)),
    save: protectedProcedure
      .input(conversationSchema)
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.id < 1) {
          throw new TRPCError({ code: "FORBIDDEN", message: "غير مسموح" });
        }
        const attachmentIds = Array.from(
          new Set(
            input.messages.flatMap(message =>
              (message.attachments ?? []).map(file => file.id)
            )
          )
        );
        const owned = await db.getTg6AttachmentsByIds(
          ctx.user.id,
          attachmentIds
        );
        if (owned.length !== attachmentIds.length) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "لا يمكن ربط ملف غير مملوك لهذا الحساب بالمحادثة.",
          });
        }
        return db.saveTg6Conversation(ctx.user.id, input);
      }),
    remove: protectedProcedure
      .input(z.object({ id: z.string().min(8).max(64) }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteTg6Conversation(ctx.user.id, input.id);
        return { success: true } as const;
      }),
    uploads: uploadsRouter,
  }),
});

export type AppRouter = typeof appRouter;
