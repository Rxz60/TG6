const REQUEST_HEADERS = [
  "accept",
  "authorization",
  "content-type",
  "cookie",
  "range",
  "user-agent",
  "x-request-id",
] as const;

const RESPONSE_HEADERS = [
  "cache-control",
  "content-disposition",
  "content-type",
  "etag",
  "last-modified",
  "location",
  "referrer-policy",
  "retry-after",
  "x-accel-buffering",
] as const;

export default async function tg6Proxy(request: Request): Promise<Response> {
  const configuredOrigin = process.env.TG6_API_ORIGIN;
  if (!configuredOrigin) {
    return Response.json(
      { error: "لم يُضبط خادم TG6 المرتبط بعد." },
      { status: 503, headers: { "Cache-Control": "no-store" } }
    );
  }

  let backend: URL;
  try {
    backend = new URL(configuredOrigin);
  } catch {
    return Response.json(
      { error: "إعداد خادم TG6 غير صالح." },
      { status: 500 }
    );
  }
  if (
    backend.protocol !== "https:" ||
    backend.username ||
    backend.password ||
    backend.pathname !== "/" ||
    backend.search ||
    backend.hash
  ) {
    return Response.json(
      { error: "إعداد خادم TG6 غير صالح." },
      { status: 500 }
    );
  }

  const incoming = new URL(request.url);
  const destination = new URL(
    `${incoming.pathname}${incoming.search}`,
    backend
  );
  const headers = new Headers();
  for (const name of REQUEST_HEADERS) {
    const value = request.headers.get(name);
    if (value) headers.set(name, value);
  }
  headers.set("x-forwarded-host", incoming.host);
  headers.set("x-forwarded-proto", incoming.protocol.slice(0, -1));

  const init: RequestInit & { duplex?: "half" } = {
    method: request.method,
    headers,
    redirect: "manual",
    signal: request.signal,
  };
  if (request.method !== "GET" && request.method !== "HEAD" && request.body) {
    init.body = request.body;
    init.duplex = "half";
  }

  try {
    const upstream = await fetch(destination, init);
    const responseHeaders = new Headers();
    for (const name of RESPONSE_HEADERS) {
      const value = upstream.headers.get(name);
      if (value) responseHeaders.set(name, value);
    }
    const headersWithCookies = upstream.headers as Headers & {
      getSetCookie?: () => string[];
    };
    const cookies = headersWithCookies.getSetCookie?.() ?? [];
    for (const cookie of cookies) responseHeaders.append("set-cookie", cookie);
    if (cookies.length === 0) {
      const setCookie = upstream.headers.get("set-cookie");
      if (setCookie) responseHeaders.set("set-cookie", setCookie);
    }
    responseHeaders.set("x-content-type-options", "nosniff");
    return new Response(upstream.body, {
      status: upstream.status,
      statusText: upstream.statusText,
      headers: responseHeaders,
    });
  } catch {
    return Response.json(
      { error: "تعذّر الوصول إلى خادم TG6." },
      { status: 502, headers: { "Cache-Control": "no-store" } }
    );
  }
}

export const config = {
  path: ["/api/*", "/manus-storage/*"],
  preferStatic: true,
};
