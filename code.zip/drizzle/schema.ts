import {
  index,
  int,
  longtext,
  mysqlEnum,
  mysqlTable,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing the Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: longtext("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const tg6Conversations = mysqlTable(
  "tg6_conversations",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 255 }).notNull(),
    messagesJson: longtext("messagesJson").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().notNull(),
    revision: int("revision").notNull().default(1),
    deletedAt: timestamp("deletedAt"),
  },
  table => [
    index("tg6_conversations_owner_updated_idx").on(
      table.userId,
      table.updatedAt
    ),
  ]
);

export const tg6Attachments = mysqlTable(
  "tg6_attachments",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    storagePath: varchar("storagePath", { length: 160 }).notNull().unique(),
    name: varchar("name", { length: 255 }).notNull(),
    contentType: varchar("contentType", { length: 128 }).notNull(),
    size: int("size").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    uploadedAt: timestamp("uploadedAt"),
  },
  table => [index("tg6_attachments_owner_idx").on(table.userId, table.id)]
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Tg6Conversation = typeof tg6Conversations.$inferSelect;
export type Tg6Attachment = typeof tg6Attachments.$inferSelect;
