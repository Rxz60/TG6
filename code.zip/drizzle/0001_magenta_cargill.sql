CREATE TABLE `tg6_attachments` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`storagePath` varchar(160) NOT NULL,
	`name` varchar(255) NOT NULL,
	`contentType` varchar(128) NOT NULL,
	`size` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`uploadedAt` timestamp,
	CONSTRAINT `tg6_attachments_id` PRIMARY KEY(`id`),
	CONSTRAINT `tg6_attachments_storagePath_unique` UNIQUE(`storagePath`)
);
--> statement-breakpoint
CREATE TABLE `tg6_conversations` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`messagesJson` longtext NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tg6_conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `name` longtext;--> statement-breakpoint
ALTER TABLE `tg6_attachments` ADD CONSTRAINT `tg6_attachments_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tg6_conversations` ADD CONSTRAINT `tg6_conversations_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `tg6_attachments_owner_idx` ON `tg6_attachments` (`userId`,`id`);--> statement-breakpoint
CREATE INDEX `tg6_conversations_owner_updated_idx` ON `tg6_conversations` (`userId`,`updatedAt`);