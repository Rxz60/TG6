ALTER TABLE `tg6_conversations` ADD `revision` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `tg6_conversations` ADD `deletedAt` timestamp;