import {
  ArrowDown,
  ArrowUp,
  Check,
  ChevronDown,
  Command,
  Compass,
  Copy,
  FileText,
  Image as ImageIcon,
  LoaderCircle,
  LogIn,
  LogOut,
  Menu,
  MessageSquarePlus,
  MoreHorizontal,
  Music2,
  Paperclip,
  PanelRightClose,
  Plus,
  RotateCcw,
  Search,
  Sparkles,
  Trash2,
  Video,
  X,
} from "lucide-react";
import {
  type FormEvent,
  type KeyboardEvent,
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { toast } from "sonner";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import {
  conversationSignature,
  limitRecentAttachments,
  mergeVersionedConversations,
} from "@/lib/chatContext";

const Streamdown = lazy(async () => {
  const module = await import("streamdown");
  return { default: module.Streamdown };
});

type Attachment = {
  id: string;
  name: string;
  contentType: string;
  size: number;
};

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
  attachments?: Attachment[];
  error?: boolean;
  failedUserContent?: string;
};

type Conversation = {
  id: string;
  title: string;
  revision?: number;
  updatedAt: number;
  messages: ChatMessage[];
};

type UploadedAttachment = Attachment & { downloadUrl: string };

type PendingAttachment = Attachment & { localId: string };

const LEGACY_STORAGE_KEY = "tg6-conversations-v1";
const USER_STORAGE_PREFIX = "tg6-conversations-v2-user-";
const MAX_FILE_SIZE = 50 * 1024 * 1024;
const MAX_FILES_PER_TURN = 4;
const STARTERS = [
  {
    icon: Compass,
    title: "خطّط لي رحلة",
    detail: "اقترح برنامجًا ممتعًا لعطلة قصيرة.",
  },
  {
    icon: FileText,
    title: "اكتب بوضوح",
    detail: "ساعدني في صياغة رسالة احترافية.",
  },
  { icon: Sparkles, title: "اشرح لي فكرة", detail: "بأسلوب بسيط، خطوةً خطوة." },
];

function readConversations(key = LEGACY_STORAGE_KEY): Conversation[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    if (!Array.isArray(value)) return [];
    return value.filter(
      (item): item is Conversation =>
        !!item &&
        typeof item.id === "string" &&
        typeof item.title === "string" &&
        Array.isArray(item.messages)
    );
  } catch {
    return [];
  }
}

const mergeConversations = mergeVersionedConversations;

function newId() {
  return (
    crypto.randomUUID?.() ??
    `${Date.now()}-${Math.random().toString(36).slice(2)}`
  );
}

function fileUrl(file: Attachment) {
  return `/api/tg6/files/${encodeURIComponent(file.id)}`;
}

function formatBytes(value: number) {
  if (value < 1024) return `${value} بايت`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(0)} كيلوبايت`;
  return `${(value / (1024 * 1024)).toFixed(1)} ميغابايت`;
}

function AttachmentIcon({ contentType }: { contentType: string }) {
  if (contentType.startsWith("image/")) return <ImageIcon size={15} />;
  if (contentType.startsWith("video/")) return <Video size={15} />;
  if (contentType.startsWith("audio/")) return <Music2 size={15} />;
  return <FileText size={15} />;
}

function TG6Mark({ small = false }: { small?: boolean }) {
  return (
    <span
      className={`tg6-mark${small ? " tg6-mark-small" : ""}`}
      aria-hidden="true"
    >
      <img src="/tg6-brand.png" alt="" />
    </span>
  );
}

export default function Home() {
  const auth = useAuth();
  const scope = auth.loading
    ? "loading"
    : auth.user
      ? `user:${auth.user.id}`
      : "guest";
  const cloudQuery = trpc.chat.list.useQuery(
    { cacheScope: scope },
    {
      enabled: Boolean(auth.user) && !auth.loading,
      retry: false,
      refetchOnWindowFocus: false,
    }
  );
  const saveConversation = trpc.chat.save.useMutation();
  const removeConversation = trpc.chat.remove.useMutation();
  const createUpload = trpc.chat.uploads.create.useMutation();
  const completeUpload = trpc.chat.uploads.complete.useMutation();
  const cancelUpload = trpc.chat.uploads.cancel.useMutation();

  const [conversations, setConversations] = useState<Conversation[]>(() =>
    readConversations()
  );
  const [activeId, setActiveId] = useState<string | null>(
    () => readConversations()[0]?.id ?? null
  );
  const [draft, setDraft] = useState("");
  const [pendingAttachments, setPendingAttachments] = useState<
    PendingAttachment[]
  >([]);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [hydratedScope, setHydratedScope] = useState<string | null>(null);
  const [legacyConversations, setLegacyConversations] = useState<
    Conversation[]
  >([]);
  const [legacyPromptOpen, setLegacyPromptOpen] = useState(false);
  const [cloudSyncError, setCloudSyncError] = useState(false);
  const [syncTick, setSyncTick] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const lastScope = useRef(scope);
  const currentScope = useRef(scope);
  currentScope.current = scope;
  const savedSnapshot = useRef(new Map<string, string>());
  const pendingSaves = useRef(new Set<string>());
  const pendingSavePromises = useRef(
    new Map<string, Promise<Conversation | null>>()
  );
  const deletedConversationKeys = useRef(new Set<string>());
  const latestConversations = useRef(conversations);
  latestConversations.current = conversations;

  const persistConversation = useCallback(
    (conversation: Conversation, targetScope: string) => {
      const saveKey = `${targetScope}:${conversation.id}`;
      if (deletedConversationKeys.current.has(saveKey))
        return Promise.resolve(null);
      const pending = pendingSavePromises.current.get(saveKey);
      if (pending) return pending;

      pendingSaves.current.add(saveKey);
      let request: Promise<Conversation | null>;
      request = saveConversation
        .mutateAsync(conversation)
        .then(saved => {
          const serverVersion = saved as Conversation;
          if (!deletedConversationKeys.current.has(saveKey)) {
            savedSnapshot.current.set(
              saveKey,
              conversationSignature(serverVersion)
            );
            if (currentScope.current === targetScope) {
              const current = latestConversations.current.find(
                item => item.id === conversation.id
              );
              if (current) {
                const merged = mergeConversations(
                  [current],
                  [serverVersion]
                )[0];
                if (
                  merged &&
                  (conversationSignature(current) !==
                    conversationSignature(merged) ||
                    current.revision !== merged.revision ||
                    current.updatedAt !== merged.updatedAt)
                ) {
                  const next = latestConversations.current.map(item =>
                    item.id === merged.id ? merged : item
                  );
                  latestConversations.current = next;
                  setConversations(items =>
                    items.map(item => (item.id === merged.id ? merged : item))
                  );
                }
              }
            }
          }
          if (currentScope.current === targetScope) setCloudSyncError(false);
          return serverVersion;
        })
        .catch(() => {
          if (
            currentScope.current === targetScope &&
            !deletedConversationKeys.current.has(saveKey)
          ) {
            setCloudSyncError(true);
          }
          return null;
        })
        .finally(() => {
          pendingSaves.current.delete(saveKey);
          if (pendingSavePromises.current.get(saveKey) === request) {
            pendingSavePromises.current.delete(saveKey);
          }
        });
      pendingSavePromises.current.set(saveKey, request);

      void request.then(saved => {
        if (
          !saved ||
          currentScope.current !== targetScope ||
          deletedConversationKeys.current.has(saveKey)
        ) {
          return;
        }
        const newest = latestConversations.current.find(
          item => item.id === conversation.id
        );
        if (
          newest &&
          conversationSignature(newest) !== conversationSignature(saved)
        ) {
          setSyncTick(value => value + 1);
        }
      });
      return request;
    },
    [saveConversation.mutateAsync]
  );

  const isReady = hydratedScope === scope;
  const visibleDraft = isReady ? draft : "";
  const visibleSearch = isReady ? search : "";
  const visiblePendingAttachments = isReady ? pendingAttachments : [];
  const active = isReady
    ? (conversations.find(conversation => conversation.id === activeId) ?? null)
    : null;
  const messages = active?.messages ?? [];
  const filteredConversations = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("ar");
    return conversations.filter(
      conversation =>
        !query || conversation.title.toLocaleLowerCase("ar").includes(query)
    );
  }, [conversations, search]);

  useEffect(() => {
    if (scope === "loading" || lastScope.current === scope) return;
    lastScope.current = scope;
    const localKey = auth.user
      ? `${USER_STORAGE_PREFIX}${auth.user.id}`
      : LEGACY_STORAGE_KEY;
    const local = readConversations(localKey);
    setConversations(local);
    setActiveId(local[0]?.id ?? null);
    setHydratedScope(null);
    setDraft("");
    setPendingAttachments([]);
    setSearch("");
    setLegacyConversations([]);
    setLegacyPromptOpen(false);
    setCloudSyncError(false);
    savedSnapshot.current.clear();
  }, [auth.user?.id, scope]);

  useEffect(() => {
    if (auth.loading) return;
    if (auth.user && !cloudQuery.isSuccess && !cloudQuery.isError) return;
    const nextScope = auth.user ? `user:${auth.user.id}` : "guest";
    if (hydratedScope === nextScope) return;

    const localKey = auth.user
      ? `${USER_STORAGE_PREFIX}${auth.user.id}`
      : LEGACY_STORAGE_KEY;
    const cached = readConversations(localKey);
    const cloudSnapshot =
      auth.user && cloudQuery.isSuccess
        ? (cloudQuery.data ?? { conversations: [], deletedIds: [] })
        : { conversations: [], deletedIds: [] };
    const deletedIds = new Set(cloudSnapshot.deletedIds);
    if (auth.user) {
      for (const id of deletedIds) {
        deletedConversationKeys.current.add(`user:${auth.user.id}:${id}`);
      }
    }
    const cloud = cloudSnapshot.conversations;
    const survivingCache = cached.filter(
      conversation => !deletedIds.has(conversation.id)
    );
    const merged = auth.user
      ? mergeConversations(cloud, survivingCache)
      : cached;

    savedSnapshot.current.clear();
    for (const conversation of cloud) {
      savedSnapshot.current.set(
        `${nextScope}:${conversation.id}`,
        conversationSignature(conversation)
      );
    }
    setConversations(merged);
    setActiveId(merged[0]?.id ?? null);
    setLegacyConversations([]);
    setLegacyPromptOpen(false);

    if (auth.user) {
      const marker = `tg6-legacy-import-${auth.user.id}`;
      const legacy = localStorage.getItem(marker)
        ? []
        : readConversations(LEGACY_STORAGE_KEY);
      setLegacyConversations(legacy);
      setLegacyPromptOpen(legacy.length > 0);
      if (cloudQuery.isError) {
        setCloudSyncError(true);
        toast.error("تعذّرت مزامنة السحابة الآن؛ احتفظنا بنسخة محلية.");
      }
    } else {
      setCloudSyncError(false);
    }
    setHydratedScope(nextScope);
  }, [
    auth.loading,
    auth.user,
    cloudQuery.data,
    cloudQuery.isError,
    cloudQuery.isSuccess,
    hydratedScope,
  ]);

  useEffect(() => {
    if (!isReady) return;
    const cacheKey = auth.user
      ? `${USER_STORAGE_PREFIX}${auth.user.id}`
      : LEGACY_STORAGE_KEY;
    let serialized = "";
    const timer = window.setTimeout(() => {
      try {
        serialized = JSON.stringify(conversations);
        localStorage.setItem(cacheKey, serialized);
      } catch {
        toast.error("تعذّر حفظ النسخة المحلية على هذا الجهاز.");
      }

      if (!auth.user || cloudQuery.isError) return;
      for (const conversation of conversations) {
        const signature = conversationSignature(conversation);
        const saveKey = `${scope}:${conversation.id}`;
        if (
          savedSnapshot.current.get(saveKey) === signature ||
          pendingSaves.current.has(saveKey) ||
          deletedConversationKeys.current.has(saveKey)
        ) {
          continue;
        }
        void persistConversation(conversation, scope);
      }
    }, 850);
    return () => window.clearTimeout(timer);
  }, [
    conversations,
    auth.user,
    cloudQuery.isError,
    isReady,
    persistConversation,
    syncTick,
  ]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, messages.at(-1)?.content]);

  const startNewChat = () => {
    if (busy || uploading || !isReady) return;
    setActiveId(null);
    setDraft("");
    setPendingAttachments([]);
    setSidebarOpen(false);
    window.setTimeout(() => textareaRef.current?.focus(), 80);
  };

  const deleteConversation = async (id: string) => {
    if (busy && activeId === id) return;
    const conversation = conversations.find(item => item.id === id);
    if (!conversation) return;
    const targetScope = scope;
    const saveKey = `${targetScope}:${id}`;
    if (auth.user) deletedConversationKeys.current.add(saveKey);
    const remaining = conversations.filter(
      conversation => conversation.id !== id
    );
    latestConversations.current = latestConversations.current.filter(
      conversation => conversation.id !== id
    );
    setConversations(remaining);
    savedSnapshot.current.delete(saveKey);
    if (activeId === id) setActiveId(remaining[0]?.id ?? null);
    if (!auth.user) {
      toast.success("حُذفت المحادثة من سجل TG6.");
      return;
    }

    try {
      const pending = pendingSavePromises.current.get(saveKey);
      if (pending) await pending;
      if (currentScope.current !== targetScope) return;
      await removeConversation.mutateAsync({ id });
      if (currentScope.current === targetScope) {
        toast.success("حُذفت المحادثة من سجل TG6.");
      }
    } catch {
      if (currentScope.current !== targetScope) return;
      deletedConversationKeys.current.delete(saveKey);
      const restored = mergeConversations(latestConversations.current, [
        conversation,
      ]);
      latestConversations.current = restored;
      setConversations(restored);
      setCloudSyncError(true);
      toast.error("تعذّر حذف المحادثة من السحابة؛ أعد المحاولة.");
    }
  };

  const appendAssistantText = (
    conversationId: string,
    messageId: string,
    text: string
  ) => {
    setConversations(current =>
      current.map(conversation =>
        conversation.id !== conversationId
          ? conversation
          : {
              ...conversation,
              updatedAt: Date.now(),
              messages: conversation.messages.map(message =>
                message.id === messageId
                  ? { ...message, content: message.content + text }
                  : message
              ),
            }
      )
    );
  };

  const submitMessage = async (
    value = draft,
    retry?: { conversationId: string; assistantId: string }
  ) => {
    const text = value.trim();
    if (busy || uploading) return;
    if (!auth.user) {
      toast.message("سجّل الدخول لحفظ محادثاتك واستخدام TG6.");
      return;
    }
    if (!text && !pendingAttachments.length && !retry) return;

    const now = Date.now();
    const conversationId = retry?.conversationId ?? active?.id ?? newId();
    const retryConversation = retry
      ? conversations.find(
          conversation => conversation.id === retry.conversationId
        )
      : active;
    const retryAssistantIndex = retry
      ? (retryConversation?.messages.findIndex(
          message => message.id === retry.assistantId
        ) ?? -1)
      : -1;
    if (retry && (!retryConversation || retryAssistantIndex < 0)) return;

    const assistantId = retry?.assistantId ?? newId();
    const userMessage: ChatMessage = {
      id: newId(),
      role: "user",
      content: text,
      createdAt: now,
      attachments: retry
        ? undefined
        : pendingAttachments.map(({ localId: _localId, ...file }) => file),
    };
    const placeholder: ChatMessage = {
      id: assistantId,
      role: "assistant",
      content: "",
      createdAt: now,
    };
    const base = retryConversation ?? {
      id: conversationId,
      title: text.replace(/\s+/g, " ").slice(0, 54) || "محادثة جديدة",
      updatedAt: now,
      messages: [],
    };
    const nextMessages = retry
      ? base.messages.map(message =>
          message.id === assistantId
            ? {
                ...message,
                content: "",
                error: false,
                failedUserContent: undefined,
                createdAt: now,
              }
            : message
        )
      : [...base.messages, userMessage, placeholder];
    const requestMessages = retry
      ? base.messages.slice(0, retryAssistantIndex)
      : [...base.messages, userMessage];

    setActiveId(conversationId);
    setDraft("");
    if (!retry) setPendingAttachments([]);
    setBusy(true);
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    setConversations(current => {
      const found = current.some(
        conversation => conversation.id === conversationId
      );
      return found
        ? current.map(conversation =>
            conversation.id === conversationId
              ? { ...conversation, updatedAt: now, messages: nextMessages }
              : conversation
          )
        : [{ ...base, updatedAt: now, messages: nextMessages }, ...current];
    });

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "text/event-stream",
        },
        body: JSON.stringify({
          messages: limitRecentAttachments(
            requestMessages
              .filter(message => !message.error)
              .filter(
                message => message.content.trim() || message.attachments?.length
              )
              .slice(-24)
              .map(message => ({
                role: message.role,
                content: message.content,
                attachmentIds: message.attachments?.map(file => file.id) ?? [],
              }))
          ),
        }),
      });

      if (!response.ok) {
        let detail = "تعذّر الاتصال بالمساعد الآن. حاول مرة أخرى بعد قليل.";
        try {
          const result = (await response.json()) as { error?: string };
          if (result.error) detail = result.error;
        } catch {
          /* keep the friendly fallback */
        }
        throw new Error(detail);
      }
      if (!response.body)
        throw new Error("لم يصل ردّ من المساعد. حاول مرة أخرى.");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let receivedText = "";
      let streamError: string | null = null;
      let streamDone = false;

      const consumeEvent = (event: string) => {
        for (const line of event.split("\n")) {
          if (!line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (data === "[DONE]") {
            streamDone = true;
            continue;
          }
          try {
            const payload = JSON.parse(data) as {
              choices?: Array<{
                delta?: { content?: string | Array<{ text?: string }> };
              }>;
              error?: { message?: string } | string;
            };
            if (payload.error) {
              streamError =
                typeof payload.error === "string"
                  ? payload.error
                  : (payload.error.message ?? "حدث خطأ أثناء إنشاء الرد.");
              continue;
            }
            const content = payload.choices?.[0]?.delta?.content;
            const piece =
              typeof content === "string"
                ? content
                : Array.isArray(content)
                  ? content.map(part => part.text ?? "").join("")
                  : "";
            if (piece) {
              receivedText += piece;
              appendAssistantText(conversationId, assistantId, piece);
            }
          } catch {
            /* incomplete SSE events are collected with the following chunk */
          }
        }
      };

      while (!streamDone) {
        const { value: chunk, done } = await reader.read();
        if (done) break;
        buffer += decoder
          .decode(chunk, { stream: true })
          .replace(/\r\n/g, "\n");
        let separator = buffer.indexOf("\n\n");
        while (separator !== -1) {
          consumeEvent(buffer.slice(0, separator));
          buffer = buffer.slice(separator + 2);
          separator = buffer.indexOf("\n\n");
        }
      }
      if (buffer.trim()) consumeEvent(buffer);
      if (streamError) throw new Error(streamError);
      if (!receivedText.trim())
        throw new Error("لم يصل ردّ مكتمل. أعد المحاولة.");
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "حدث خطأ غير متوقع. حاول مرة أخرى.";
      if (!retry) setDraft(text);
      setConversations(current =>
        current.map(conversation =>
          conversation.id !== conversationId
            ? conversation
            : {
                ...conversation,
                messages: conversation.messages.map(item =>
                  item.id === assistantId
                    ? {
                        ...item,
                        content: item.content || message,
                        error: true,
                        failedUserContent: text || "المرفقات",
                      }
                    : item
                ),
              }
        )
      );
    } finally {
      setBusy(false);
      window.setTimeout(() => textareaRef.current?.focus(), 0);
    }
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void submitMessage();
  };

  const retryMessage = (message: ChatMessage) => {
    if (!activeId || !message.failedUserContent) return;
    void submitMessage(message.failedUserContent, {
      conversationId: activeId,
      assistantId: message.id,
    });
  };

  const copyMessage = async (message: ChatMessage) => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopiedId(message.id);
      window.setTimeout(() => setCopiedId(null), 1600);
    } catch {
      toast.error("لم نتمكن من نسخ الرد.");
    }
  };

  const chooseConversation = (id: string) => {
    if (busy) return;
    setActiveId(id);
    setSidebarOpen(false);
  };

  const onDraftKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (
      event.key === "Enter" &&
      !event.shiftKey &&
      !event.nativeEvent.isComposing
    ) {
      event.preventDefault();
      void submitMessage();
    }
  };

  const handleLogin = () => {
    try {
      startLogin();
    } catch {
      toast.error("تعذّر بدء تسجيل الدخول. حاول فتح الموقع في نافذة جديدة.");
    }
  };

  const uploadSelectedFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    if (!auth.user) {
      toast.message("سجّل الدخول أولًا لرفع الملفات بأمان.");
      handleLogin();
      return;
    }
    const selected = Array.from(files);
    const available = MAX_FILES_PER_TURN - pendingAttachments.length;
    if (selected.length > available) {
      toast.error(
        `يمكن إرفاق ${MAX_FILES_PER_TURN} ملفات كحد أقصى في الرسالة.`
      );
    }
    const accepted = selected.slice(0, Math.max(0, available));
    if (!accepted.length) return;
    for (const file of accepted) {
      if (file.size > MAX_FILE_SIZE) {
        toast.error(`حجم «${file.name}» يتجاوز 50 ميغابايت.`);
        return;
      }
    }

    setUploading(true);
    let pendingUploadId: string | null = null;
    try {
      for (const file of accepted) {
        const contentType = file.type || "application/octet-stream";
        const created = await createUpload.mutateAsync({
          name: file.name,
          contentType,
          size: file.size,
        });
        pendingUploadId = created.id;
        const uploaded = await fetch(created.uploadUrl, {
          method: "PUT",
          headers: { "Content-Type": contentType },
          body: file,
        });
        if (!uploaded.ok) throw new Error(`تعذّر رفع «${file.name}».`);
        const complete = await completeUpload.mutateAsync({ id: created.id });
        pendingUploadId = null;
        setPendingAttachments(current => [
          ...current,
          {
            id: complete.id,
            name: complete.name,
            contentType: complete.contentType,
            size: complete.size,
            localId: newId(),
          },
        ]);
      }
      toast.success("اكتمل رفع المرفقات إلى تخزين TG6 السحابي.");
    } catch (error) {
      if (pendingUploadId) {
        try {
          await cancelUpload.mutateAsync({ id: pendingUploadId });
        } catch {
          /* the original upload error is more useful to the user */
        }
      }
      toast.error(error instanceof Error ? error.message : "تعذّر رفع الملف.");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
      textareaRef.current?.focus();
    }
  };

  const importLegacyConversations = async () => {
    if (!auth.user || !legacyConversations.length) return;
    try {
      const imported: Conversation[] = [];
      for (const conversation of legacyConversations) {
        if (currentScope.current !== scope) return;
        const saved = await persistConversation(conversation, scope);
        if (!saved) throw new Error("Cloud conversation import failed");
        savedSnapshot.current.set(
          `${scope}:${conversation.id}`,
          conversationSignature(saved)
        );
        const [mergedConversation] = mergeConversations(
          [conversation],
          [saved]
        );
        imported.push(mergedConversation);
      }
      if (currentScope.current !== scope) return;
      const merged = mergeConversations(conversations, imported);
      latestConversations.current = merged;
      setConversations(merged);
      localStorage.setItem(`tg6-legacy-import-${auth.user.id}`, "done");
      setLegacyPromptOpen(false);
      setLegacyConversations([]);
      toast.success("نُقلت محادثات هذا الجهاز إلى حسابك.");
    } catch {
      toast.error("تعذّر استيراد بعض المحادثات. ستبقى محفوظة على هذا الجهاز.");
    }
  };

  const dismissLegacyImport = () => {
    if (auth.user) {
      localStorage.setItem(`tg6-legacy-import-${auth.user.id}`, "later");
    }
    setLegacyPromptOpen(false);
  };

  const signOut = async () => {
    try {
      await auth.logout();
      setActiveId(null);
      setConversations([]);
      setHydratedScope(null);
      setDraft("");
      setPendingAttachments([]);
      setSearch("");
      toast.success("تم تسجيل الخروج.");
    } catch {
      toast.error("تعذّر تسجيل الخروج الآن.");
    }
  };

  return (
    <div className="tg6-app" dir="rtl">
      {sidebarOpen && (
        <button
          className="sidebar-scrim"
          aria-label="إغلاق القائمة"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`chat-sidebar${sidebarOpen ? " sidebar-open" : ""}`}
        aria-label="قائمة المحادثات"
      >
        <div className="sidebar-topline">
          <a className="brand-lockup" href="/" aria-label="TG6 الصفحة الرئيسية">
            <TG6Mark small />
            <span className="brand-name">
              TG<span>6</span>
            </span>
          </a>
          <button
            className="icon-button sidebar-close"
            aria-label="إغلاق القائمة"
            onClick={() => setSidebarOpen(false)}
          >
            <PanelRightClose size={18} />
          </button>
        </div>

        <button
          className="new-chat-button"
          onClick={startNewChat}
          disabled={busy || uploading || !isReady}
        >
          <MessageSquarePlus size={17} strokeWidth={1.8} />
          <span>محادثة جديدة</span>
          <span className="new-chat-key">
            <Command size={11} /> K
          </span>
        </button>

        <label className="conversation-search">
          <Search size={15} />
          <input
            value={visibleSearch}
            disabled={!isReady}
            onChange={event => setSearch(event.target.value)}
            placeholder="ابحث في محادثاتك"
            aria-label="ابحث في المحادثات"
          />
          {visibleSearch && (
            <button
              type="button"
              aria-label="مسح البحث"
              onClick={() => setSearch("")}
            >
              <X size={14} />
            </button>
          )}
        </label>

        <div className="history-heading">
          <span>محادثاتك</span>
          <MoreHorizontal size={17} />
        </div>
        <div className="conversation-list">
          {!isReady ? (
            <p className="history-empty">يجري تجهيز سجلّك...</p>
          ) : filteredConversations.length === 0 ? (
            <p className="history-empty">
              {search ? "لا توجد نتائج مطابقة." : "ستظهر محادثاتك هنا."}
            </p>
          ) : (
            filteredConversations.map(conversation => (
              <div
                key={conversation.id}
                className={`conversation-item${activeId === conversation.id ? " conversation-active" : ""}`}
              >
                <button
                  className="conversation-select"
                  onClick={() => chooseConversation(conversation.id)}
                  title={conversation.title}
                >
                  <MessageSquarePlus size={15} />
                  <span>{conversation.title}</span>
                </button>
                <button
                  className="conversation-delete"
                  aria-label={`حذف ${conversation.title}`}
                  title="حذف المحادثة"
                  onClick={() => deleteConversation(conversation.id)}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))
          )}
        </div>

        <div className="sidebar-bottom">
          {auth.user && legacyPromptOpen && legacyConversations.length > 0 && (
            <div className="legacy-import-note">
              <div>
                <strong>محادثات قديمة على جهازك</strong>
                <span>انقلها إلى سجلّك السحابي؟</span>
              </div>
              <div className="legacy-import-actions">
                <button onClick={() => void importLegacyConversations()}>
                  استيراد
                </button>
                <button onClick={dismissLegacyImport}>لاحقًا</button>
              </div>
            </div>
          )}
          <div className="privacy-note">
            <span
              className={`privacy-dot${cloudSyncError ? " sync-error" : ""}`}
            />
            <span>
              {auth.user
                ? cloudSyncError
                  ? "تعذّرت المزامنة؛ توجد نسخة محلية"
                  : saveConversation.isPending
                    ? "تتم مزامنة محادثاتك"
                    : "المحادثات متزامنة مع حسابك"
                : "وضع زائر: الحفظ على هذا الجهاز"}
            </span>
          </div>
          <button
            className="sidebar-profile"
            onClick={() => (auth.user ? void signOut() : handleLogin())}
            title={auth.user ? "تسجيل الخروج" : "تسجيل الدخول"}
          >
            <span className="profile-avatar">
              {auth.user?.name?.trim()?.[0] ??
                (auth.user ? "T" : <LogIn size={15} />)}
            </span>
            <span className="profile-copy">
              <strong>
                {auth.user?.name || (auth.user ? "حساب TG6" : "زائر")}
              </strong>
              <small>
                {auth.user ? "تسجيل الخروج" : "سجّل للمزامنة والبدء"}
              </small>
            </span>
            {auth.user ? (
              <LogOut size={15} className="profile-chevron" />
            ) : (
              <ChevronDown size={15} className="profile-chevron" />
            )}
          </button>
        </div>
      </aside>

      <main className="chat-main">
        <header className="chat-header">
          <div className="header-start">
            <button
              className="icon-button mobile-menu"
              aria-label="فتح قائمة المحادثات"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={20} />
            </button>
            <div className="model-selector" aria-label="نموذج TG6">
              <span className="model-emblem">
                <TG6Mark small />
              </span>
              <span className="model-title">TG6</span>
              <span className="model-label">المساعد الذكي</span>
              <ChevronDown size={14} className="model-chevron" />
            </div>
          </div>
          <div className="header-actions">
            <span
              className={`online-status${cloudSyncError ? " status-error" : ""}`}
            >
              <span />
              {auth.loading
                ? "يتصل بحسابك"
                : !auth.user
                  ? "وضع الزائر"
                  : cloudSyncError
                    ? "مزامنة معلّقة"
                    : "TG6 متصل"}
            </span>
            {!auth.user && (
              <button className="login-button" onClick={handleLogin}>
                <LogIn size={15} /> تسجيل الدخول
              </button>
            )}
            <button
              className="header-new-chat"
              aria-label="محادثة جديدة"
              onClick={startNewChat}
              disabled={busy || uploading || !isReady}
            >
              <Plus size={17} />
              <span>محادثة جديدة</span>
            </button>
          </div>
        </header>

        <section className="conversation-stage" aria-label="محادثة TG6">
          {!isReady ? (
            <div className="loading-stage">
              <LoaderCircle size={24} className="loading-spin" />
              <span>نجهّز مساحة TG6 الخاصة بك</span>
            </div>
          ) : messages.length === 0 ? (
            <div className="welcome-panel">
              <div className="welcome-orbit">
                <div className="orbit-ring orbit-ring-one" />
                <div className="orbit-ring orbit-ring-two" />
                <div className="welcome-mark">
                  <TG6Mark />
                </div>
                <span className="orbit-spark orbit-spark-a">✳</span>
                <span className="orbit-spark orbit-spark-b">✦</span>
              </div>
              <p className="welcome-eyebrow">
                <span /> مساحة أفكارك تبدأ هنا
              </p>
              <h1>
                أهلًا بك، أنا <span>TG6</span>
              </h1>
              <p className="welcome-subtitle">
                فكّر بصوت عالٍ. اسأل. أنشئ شيئًا جديدًا.
                <br className="desktop-only" /> وأنا معك في كل خطوة.
              </p>
              {!auth.user && (
                <button className="welcome-login" onClick={handleLogin}>
                  <LogIn size={16} /> سجّل الدخول لبدء محادثة سحابية
                </button>
              )}
              <div className="starter-grid">
                {STARTERS.map(({ icon: Icon, title, detail }) => (
                  <button
                    key={title}
                    className="starter-card"
                    onClick={() => {
                      setDraft(`${title}: `);
                      textareaRef.current?.focus();
                    }}
                  >
                    <span className="starter-icon">
                      <Icon size={18} strokeWidth={1.7} />
                    </span>
                    <span className="starter-copy">
                      <strong>{title}</strong>
                      <small>{detail}</small>
                    </span>
                    <ArrowDown className="starter-arrow" size={15} />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="message-thread">
              <div className="thread-date">
                <span /> بداية المحادثة <span />
              </div>
              {messages.map(message =>
                message.role === "user" ? (
                  <article
                    key={message.id}
                    className="message-row message-user-row"
                  >
                    <div className="user-bubble">
                      {message.content && (
                        <p className="user-message-text">{message.content}</p>
                      )}
                      {message.attachments?.map(attachment => (
                        <a
                          key={attachment.id}
                          className="message-attachment-chip"
                          href={fileUrl(attachment)}
                          target="_blank"
                          rel="noreferrer"
                          title={`فتح ${attachment.name}`}
                        >
                          {attachment.contentType.startsWith("image/") ? (
                            <img
                              src={fileUrl(attachment)}
                              alt={attachment.name}
                              loading="lazy"
                            />
                          ) : (
                            <span className="attachment-file-icon">
                              <AttachmentIcon
                                contentType={attachment.contentType}
                              />
                            </span>
                          )}
                          <span className="attachment-chip-copy">
                            <strong>{attachment.name}</strong>
                            <small>{formatBytes(attachment.size)}</small>
                          </span>
                        </a>
                      ))}
                    </div>
                  </article>
                ) : (
                  <article
                    key={message.id}
                    className={`message-row message-assistant-row${message.error ? " message-error" : ""}`}
                  >
                    <div className="assistant-avatar">
                      <TG6Mark small />
                    </div>
                    <div className="assistant-message-body">
                      {message.content ? (
                        <div className="markdown-body">
                          <Suspense
                            fallback={
                              <span className="markdown-loading">
                                يجري تنسيق الرد...
                              </span>
                            }
                          >
                            <Streamdown>{message.content}</Streamdown>
                          </Suspense>
                        </div>
                      ) : busy && message.id === messages.at(-1)?.id ? (
                        <div className="thinking-state">
                          <span className="thinking-dots">
                            <i />
                            <i />
                            <i />
                          </span>
                          <span>يرتّب أفكاره</span>
                        </div>
                      ) : null}
                      {message.error && (
                        <div className="message-error-actions">
                          <p className="message-help">
                            احتفظنا برسالتك؛ أعد المحاولة أو أرسلها بصياغة
                            مختلفة.
                          </p>
                          {message.failedUserContent && (
                            <button
                              className="retry-message-button"
                              onClick={() => retryMessage(message)}
                              disabled={busy}
                            >
                              <RotateCcw size={13} /> إعادة المحاولة
                            </button>
                          )}
                        </div>
                      )}
                      {message.content && !message.error && (
                        <div className="message-tools">
                          <button
                            onClick={() => void copyMessage(message)}
                            aria-label="نسخ الرد"
                            title="نسخ الرد"
                          >
                            {copiedId === message.id ? (
                              <Check size={14} />
                            ) : (
                              <Copy size={14} />
                            )}
                            {copiedId === message.id && <span>نُسخ</span>}
                          </button>
                        </div>
                      )}
                    </div>
                  </article>
                )
              )}
              <div ref={bottomRef} />
            </div>
          )}
        </section>

        <footer className="composer-footer">
          <form className="composer-shell" onSubmit={handleSubmit}>
            {visiblePendingAttachments.length > 0 && (
              <div
                className="pending-attachments"
                aria-label="المرفقات الجاهزة للإرسال"
              >
                {visiblePendingAttachments.map(attachment => (
                  <div className="pending-attachment" key={attachment.localId}>
                    <span className="pending-file-icon">
                      <AttachmentIcon contentType={attachment.contentType} />
                    </span>
                    <span className="pending-file-copy">
                      <strong>{attachment.name}</strong>
                      <small>{formatBytes(attachment.size)}</small>
                    </span>
                    <button
                      type="button"
                      aria-label={`إزالة ${attachment.name}`}
                      onClick={() =>
                        setPendingAttachments(current =>
                          current.filter(
                            item => item.localId !== attachment.localId
                          )
                        )
                      }
                      disabled={busy}
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <textarea
              ref={textareaRef}
              value={visibleDraft}
              onChange={event => {
                setDraft(event.target.value);
                event.currentTarget.style.height = "auto";
                event.currentTarget.style.height = `${Math.min(event.currentTarget.scrollHeight, 190)}px`;
              }}
              onKeyDown={onDraftKeyDown}
              placeholder="اكتب ما يدور في بالك..."
              aria-label="رسالتك إلى TG6"
              rows={1}
              maxLength={12000}
              disabled={busy || !isReady}
            />
            <div className="composer-controls">
              <div className="composer-leading-actions">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  hidden
                  onChange={event =>
                    void uploadSelectedFiles(event.target.files)
                  }
                />
                <button
                  className="attachment-button"
                  type="button"
                  title="إرفاق صور أو فيديوهات أو ملفات (50 ميغابايت للملف)"
                  aria-label="إرفاق ملف"
                  disabled={busy || uploading || !isReady}
                  onClick={() => fileInputRef.current?.click()}
                >
                  {uploading ? (
                    <LoaderCircle size={17} className="loading-spin" />
                  ) : (
                    <Paperclip size={17} />
                  )}
                  <span>{uploading ? "يرفع الملفات" : "إرفاق"}</span>
                </button>
                <span className="composer-hint">
                  {auth.user
                    ? "تخزين سحابي خاص بحسابك"
                    : "سجّل الدخول لإرسال الرسائل"}
                </span>
              </div>
              <div className="composer-actions">
                <span className="enter-hint">
                  Enter للإرسال <span>·</span> Shift + Enter لسطر جديد
                </span>
                <button
                  className={`send-button${visibleDraft.trim() || visiblePendingAttachments.length ? " send-ready" : ""}`}
                  type="submit"
                  disabled={
                    (!visibleDraft.trim() &&
                      !visiblePendingAttachments.length) ||
                    busy ||
                    uploading ||
                    !isReady
                  }
                  aria-label={busy ? "يجري إعداد الرد" : "إرسال الرسالة"}
                >
                  {busy ? (
                    <span className="send-loading" />
                  ) : (
                    <ArrowUp size={18} strokeWidth={2.2} />
                  )}
                </button>
              </div>
            </div>
          </form>
          <p className="composer-disclaimer">
            يمكن إرفاق ملفات حتى 50 ميغابايت؛ تحليل المحتوى يعتمد على صيغة الملف
            المدعومة.
          </p>
        </footer>
      </main>
    </div>
  );
}
