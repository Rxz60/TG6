export type ChatRequestMessage = {
  role: "user" | "assistant";
  content: string;
  attachmentIds: string[];
};

export type SyncMessage = {
  id: string;
  role: string;
  content: string;
  createdAt: number;
  attachments?: Array<{ id: string }>;
};

export type SyncConversation<TMessage extends SyncMessage = SyncMessage> = {
  id: string;
  title: string;
  updatedAt: number;
  revision?: number;
  messages: TMessage[];
};

const MAX_ATTACHMENTS_IN_CONTEXT = 8;
const MAX_MESSAGE_CHARS = 12_000;
const MAX_TOTAL_CONTEXT_CHARS = 30_000;

/** Content signature intentionally excludes server revision and timestamps. */
export function conversationSignature<T extends SyncConversation>(
  conversation: T
): string {
  return JSON.stringify({
    title: conversation.title,
    messages: conversation.messages.map(message => ({
      id: message.id,
      role: message.role,
      content: message.content,
      createdAt: message.createdAt,
      attachmentIds: (message.attachments ?? []).map(file => file.id),
    })),
  });
}

/**
 * Merge independent conversation revisions by message ID. The higher server
 * revision is retained, while messages added on either device remain present.
 */
export function mergeVersionedConversations<
  TMessage extends SyncMessage,
  TConversation extends SyncConversation<TMessage>,
>(...groups: TConversation[][]): TConversation[] {
  const byId = new Map<string, TConversation>();
  for (const group of groups) {
    for (const conversation of group) {
      const existing = byId.get(conversation.id);
      if (!existing) {
        byId.set(conversation.id, conversation);
        continue;
      }

      const newer =
        conversation.updatedAt >= existing.updatedAt ? conversation : existing;
      const messages = new Map<string, TMessage>();
      for (const message of existing.messages)
        messages.set(message.id, message);
      for (const message of conversation.messages) {
        const previous = messages.get(message.id);
        if (!previous || message.createdAt >= previous.createdAt) {
          messages.set(message.id, message);
        }
      }
      byId.set(conversation.id, {
        ...newer,
        updatedAt: Math.max(existing.updatedAt, conversation.updatedAt),
        revision: Math.max(existing.revision ?? 0, conversation.revision ?? 0),
        messages: [...messages.values()].sort(
          (left, right) => left.createdAt - right.createdAt
        ),
      });
    }
  }
  return [...byId.values()].sort(
    (left, right) => right.updatedAt - left.updatedAt
  );
}

function limitTextContext(
  messages: ChatRequestMessage[]
): ChatRequestMessage[] {
  let remaining = MAX_TOTAL_CONTEXT_CHARS;
  const retained: ChatRequestMessage[] = [];

  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    const allowance = Math.min(MAX_MESSAGE_CHARS, remaining);
    let content = message.content;

    if (allowance === 0) {
      content = "";
    } else if (content.length > allowance) {
      const marker = "[اختُصر جزء أقدم من الرسالة ضمن حد سياق TG6.]";
      const markerLength = marker.length + 1;
      content =
        allowance >= markerLength
          ? `${marker}\n${content.slice(-(allowance - markerLength))}`
          : content.slice(-allowance);
    }

    remaining -= content.length;
    if (content.trim() || message.attachmentIds.length > 0) {
      retained.push({ ...message, content });
    }
  }

  return retained.reverse();
}

/**
 * Keep the newest files and text inside the exact limits enforced by the API.
 * Omitted file payloads remain stored; all available message text is preferred
 * from newest to oldest and truncated only as needed to fit the request.
 */
export function limitRecentAttachments(
  messages: ChatRequestMessage[],
  maximum = MAX_ATTACHMENTS_IN_CONTEXT
): ChatRequestMessage[] {
  let remaining = Math.max(0, Math.floor(maximum));
  const result = messages.map(message => ({
    ...message,
    attachmentIds: [...message.attachmentIds],
  }));

  for (let index = result.length - 1; index >= 0; index -= 1) {
    const message = result[index];
    if (message.role !== "user" || message.attachmentIds.length === 0) continue;

    const retained = message.attachmentIds.slice(0, remaining);
    remaining -= retained.length;
    const omitted = message.attachmentIds.length - retained.length;
    result[index] = {
      ...message,
      content: omitted
        ? `${message.content}${message.content.trim() ? "\n\n" : ""}[تُركت ${omitted} من مرفقات هذه الرسالة خارج طلب النموذج لتقليل السياق؛ ما زالت محفوظة في سجل TG6.]`
        : message.content,
      attachmentIds: retained,
    };
  }

  return limitTextContext(result);
}
