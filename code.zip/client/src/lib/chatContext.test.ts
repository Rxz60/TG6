import { describe, expect, it } from "vitest";
import {
  conversationSignature,
  limitRecentAttachments,
  mergeVersionedConversations,
  type ChatRequestMessage,
  type SyncConversation,
} from "./chatContext";

function userMessage(index: number, count: number): ChatRequestMessage {
  return {
    role: "user",
    content: `رسالة ${index}`,
    attachmentIds: Array.from(
      { length: count },
      (_, file) => `file-${index}-${file}`
    ),
  };
}

function conversation(
  revision: number,
  updatedAt: number,
  messages: SyncConversation["messages"]
): SyncConversation {
  return { id: "shared-id", title: "محادثة", revision, updatedAt, messages };
}

describe("TG6 chat synchronization", () => {
  it("keeps the newest eight files across repeated four-file turns", () => {
    const result = limitRecentAttachments([
      userMessage(1, 4),
      { role: "assistant", content: "رد 1", attachmentIds: [] },
      userMessage(2, 4),
      { role: "assistant", content: "رد 2", attachmentIds: [] },
      userMessage(3, 4),
    ]);

    expect(result.flatMap(message => message.attachmentIds)).toHaveLength(8);
    expect(result[0].attachmentIds).toHaveLength(0);
    expect(result[0].content).toContain("رسالة 1");
    expect(result[0].content).toContain("ما زالت محفوظة");
    expect(result[2].attachmentIds).toHaveLength(4);
    expect(result[4].attachmentIds).toHaveLength(4);
  });

  it("preserves all recent files when within the budget", () => {
    const input = [userMessage(1, 2), userMessage(2, 3)];
    const result = limitRecentAttachments(input);

    expect(result.map(message => message.attachmentIds.length)).toEqual([2, 3]);
    expect(result[0].content).toBe("رسالة 1");
  });

  it("caps message and total characters without losing the newest turn", () => {
    const input: ChatRequestMessage[] = [
      { role: "user", content: "a".repeat(12_000), attachmentIds: [] },
      { role: "assistant", content: "b".repeat(12_000), attachmentIds: [] },
      { role: "user", content: "c".repeat(12_000), attachmentIds: [] },
      { role: "assistant", content: "d".repeat(12_000), attachmentIds: [] },
      { role: "user", content: "e".repeat(12_000), attachmentIds: [] },
    ];
    const result = limitRecentAttachments(input);
    const total = result.reduce(
      (sum, message) => sum + message.content.length,
      0
    );

    expect(total).toBeLessThanOrEqual(30_000);
    expect(result.every(message => message.content.length <= 12_000)).toBe(
      true
    );
    expect(result.at(-1)?.content).toBe(input.at(-1)?.content);
    expect(result[0].content).toContain("اختُصر جزء أقدم");
  });

  it("merges independent device turns and keeps the latest server revision", () => {
    const common = {
      id: "m1",
      role: "user",
      content: "البداية",
      createdAt: 100,
    };
    const cloudTurn = {
      id: "m2",
      role: "assistant",
      content: "رد الجهاز الأول",
      createdAt: 200,
    };
    const localTurn = {
      id: "m3",
      role: "user",
      content: "رسالة الجهاز الثاني",
      createdAt: 300,
    };
    const [merged] = mergeVersionedConversations(
      [conversation(4, 400, [common, cloudTurn])],
      [conversation(3, 500, [common, localTurn])]
    );

    expect(merged.revision).toBe(4);
    expect(merged.messages.map(message => message.id)).toEqual([
      "m1",
      "m2",
      "m3",
    ]);
    expect(merged.updatedAt).toBe(500);
  });

  it("does not treat timestamps or revisions as changed conversation content", () => {
    const first = conversation(1, 100, [
      { id: "m1", role: "user", content: "النص", createdAt: 100 },
    ]);
    const second = { ...first, revision: 3, updatedAt: 900 };

    expect(conversationSignature(first)).toBe(conversationSignature(second));
  });
});
